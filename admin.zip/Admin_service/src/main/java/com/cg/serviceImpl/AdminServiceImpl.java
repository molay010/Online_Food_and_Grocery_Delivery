package com.cg.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.AdminDTO; // Importing AdminDTO for data transfer between service and controller
import com.cg.entity.Admin; // Importing Admin entity class
import com.cg.exception.AdminNotFoundException; // Importing AdminNotFoundException for handling exceptions
import com.cg.repository.AdminRepository; // Importing AdminRepository for database operations
import com.cg.service.AdminService; // Importing AdminService interface

@Service 
public class AdminServiceImpl implements AdminService {

    @Autowired 
    private AdminRepository adminRepository;

    // Method to add admin
    @Override
    public Admin addAdmin(AdminDTO adminDTO) {
        Admin admin = new Admin();                 
        admin.setAdminUsername(adminDTO.getAdminUsername()); 
        admin.setAdminAddress(adminDTO.getAdminAddress());   
        admin.setAdminEmail(adminDTO.getAdminEmail());       
        admin.setPhoneNumber(adminDTO.getPhoneNumber());     
        admin.setAdminPassword(adminDTO.getAdminPassword()); 

        adminRepository.save(admin);               
        return admin;                              
    }

    // Method to update admin details
    @Override
    public String updateAdmin(int adminId, AdminDTO adminData) {
        try {
            Admin admin = adminRepository.findById(adminId).orElseThrow(() -> new AdminNotFoundException()); 
           
            if (adminData.getAdminUsername() != null)              
                admin.setAdminUsername(adminData.getAdminUsername());   
            if (adminData.getPhoneNumber() != 0)                   
                admin.setPhoneNumber(adminData.getPhoneNumber());       
            if (adminData.getAdminAddress() != null)               
                admin.setAdminAddress(adminData.getAdminAddress());     
            if (adminData.getAdminEmail() != null)                 
                admin.setAdminEmail(adminData.getAdminEmail());         
            adminRepository.save(admin);                      
        } catch (AdminNotFoundException e) {
            System.out.println(e);                            
            return "Admin data not updated";                 
        }
        return "Admin Updated Successfully";                  
    }

    // Method to delete admin
    @Override
    public String deleteAdmin(int adminId) {
        try {
            Admin admin = adminRepository.findById(adminId).orElseThrow(() -> new AdminNotFoundException()); 
            adminRepository.delete(admin);                   
        } catch (AdminNotFoundException e) {
            System.out.println(e);                           
            return "Invalid admin ID...";                    
        }
        return "Admin deleted successfully!!";              
    }

    // Method to get admin by email
    @Override
    public AdminDTO getAdminByEmail(String email) throws AdminNotFoundException {
        Admin admin = adminRepository.findByEmail(email);          
        if (admin == null) {                                       
            throw new AdminNotFoundException("Admin not found for given email...."); 
        }
        AdminDTO adminDTO = new AdminDTO();                        

        // Setting admin details to DTO
        adminDTO.setAdminAddress(admin.getAdminAddress());
        adminDTO.setAdminEmail(admin.getAdminEmail());
        adminDTO.setPhoneNumber(admin.getPhoneNumber());
        adminDTO.setAdminUsername(admin.getAdminUsername());
        adminDTO.setAdminId(admin.getAdminId());

        return adminDTO;                                          
    }

    // Method to get all admins
    @Override
    public List<AdminDTO> readAllAdmins() {
        List<Admin> admins = adminRepository.findAll();      

        List<AdminDTO> adminDTOs = new ArrayList<>();
      
        for (Admin admin : admins) {                        
            AdminDTO adminDTO = new AdminDTO();            
            // Setting admin details to DTO
            adminDTO.setAdminUsername(admin.getAdminUsername());
            adminDTO.setAdminAddress(admin.getAdminAddress());
            adminDTO.setAdminEmail(admin.getAdminEmail());
            adminDTO.setAdminPassword(admin.getAdminPassword());
            adminDTO.setPhoneNumber(admin.getPhoneNumber());
            adminDTO.setAdminId(admin.getAdminId());
            adminDTOs.add(adminDTO);                         
        }

        return adminDTOs;                                    
    }

}
