package com.cg.dto;

import lombok.Data;

@Data
public class AdminDTO {
	private int adminId;
	private String adminUsername;
	private String adminPassword;
	private String adminEmail;
	private long phoneNumber;
	private String adminAddress;
}
