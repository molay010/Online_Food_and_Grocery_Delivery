package com.cg.exception;

public class AdminNotFoundException extends Exception{
	
	public AdminNotFoundException() {
		super();
	}
	public AdminNotFoundException(String msg) {
		super(msg);
	}

}
