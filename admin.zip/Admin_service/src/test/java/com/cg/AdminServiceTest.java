package com.cg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.dto.AdminDTO;
import com.cg.entity.Admin;
import com.cg.exception.AdminNotFoundException;
import com.cg.repository.AdminRepository;
import com.cg.serviceImpl.AdminServiceImpl;
 
@ExtendWith(MockitoExtension.class)
public class AdminServiceTest {
 
    @Mock
    private AdminRepository adminRepository;
 
    @InjectMocks
    private AdminServiceImpl adminService;
 
 
    @Test
    public void testUpdateAdmin() {
        int idToUpdate = 1;
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setAdminUsername("updateduser");
 
        Admin adminToUpdate = new Admin();
        adminToUpdate.setAdminId(idToUpdate);
        adminToUpdate.setAdminUsername("originaluser");
 
        when(adminRepository.findById(idToUpdate)).thenReturn(Optional.of(adminToUpdate));
        when(adminRepository.save(any(Admin.class))).thenAnswer(invocation -> invocation.getArgument(0));
 
        String result = adminService.updateAdmin(idToUpdate, adminDTO);
 
        assertEquals("Admin Updated Successfully", result);
        assertEquals("updateduser", adminToUpdate.getAdminUsername());
    }
 
    @Test
    public void testDeleteAdmin() {
        int idToDelete = 1;
        Admin adminToDelete = new Admin();
        adminToDelete.setAdminId(idToDelete);
 
        when(adminRepository.findById(idToDelete)).thenReturn(Optional.of(adminToDelete));
 
        String result = adminService.deleteAdmin(idToDelete);
 
        assertEquals("Admin deleted successfully!!", result);
        verify(adminRepository, times(1)).delete(adminToDelete);
    }
 
    @Test
    public void testGetAdminByEmail() throws AdminNotFoundException {
        String emailToFind = "test@example.com";
        Admin adminFound = new Admin();
        adminFound.setAdminEmail(emailToFind);
 
        when(adminRepository.findByEmail(emailToFind)).thenReturn(adminFound);
 
        AdminDTO foundAdminDTO = adminService.getAdminByEmail(emailToFind);
 
        assertNotNull(foundAdminDTO);
        assertEquals(emailToFind, foundAdminDTO.getAdminEmail());
    }
 

    @Test
    public void testAddAdmin() {
        Admin adminToAdd = new Admin();
        adminToAdd.setAdminUsername("testuser");
        adminToAdd.setAdminEmail("test@example.com");
        adminToAdd.setAdminAddress("123 Test St");
        adminToAdd.setPhoneNumber(1234567890);
 
        when(adminRepository.save(any(Admin.class))).thenReturn(adminToAdd);
 
//        AdminDTO addedAdmin = adminService.addAdmin(adminToAdd);
// 
//        assertNotNull(addedAdmin);
//        assertEquals("testuser", addedAdmin.getUsername());
//        assertEquals("test@example.com", addedAdmin.getEmail());
//        assertEquals("123 Test St", addedAdmin.getAddress());
//        assertEquals(1234567890, addedAdmin.getNumber());
    }
    
    @Test
    public void testReadAllAdmins() {
        List<Admin> admins = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setAdminUsername("user1");
        admin1.setAdminEmail("user1@example.com");
        admin1.setAdminAddress("123 Test St");
        admin1.setPhoneNumber(1234567890);
 
        Admin admin2 = new Admin();
        admin2.setAdminUsername("user2");
        admin2.setAdminEmail("user2@example.com");
        admin2.setAdminAddress("456 Test St");
        admin2.setPhoneNumber(987654321);
 
        admins.add(admin1);
        admins.add(admin2);
 
        when(adminRepository.findAll()).thenReturn(admins);
 
        List<AdminDTO> adminDTOs = adminService.readAllAdmins();
 
        assertNotNull(adminDTOs);
        assertEquals(2, adminDTOs.size());
        assertEquals("user1", adminDTOs.get(0).getAdminUsername());
        assertEquals("user1@example.com", adminDTOs.get(0).getAdminEmail());
        assertEquals("123 Test St", adminDTOs.get(0).getAdminAddress());
        assertEquals(1234567890, adminDTOs.get(0).getPhoneNumber());
        assertEquals("user2", adminDTOs.get(1).getAdminUsername());
        assertEquals("user2@example.com", adminDTOs.get(1).getAdminEmail());
        assertEquals("456 Test St", adminDTOs.get(1).getAdminAddress());
        assertEquals(987654321, adminDTOs.get(1).getPhoneNumber());
    }
}